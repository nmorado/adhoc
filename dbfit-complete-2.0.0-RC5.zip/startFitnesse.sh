#!/bin/sh
cd `dirname $0`
java -cp 'lib/dbfit-docs.jar:lib/*' fitnesseMain.FitNesseMain -p 8085 -e 0 $1 $2 $3 $4 $5
